. <- savevar$emlal
isolate(.$SelectDP$dp_path <- gsub("/root/", "~/", .$SelectDP$dp_path))
isolate(.$DataFiles$dp_data_files$metadatapath <- gsub("/root/", "~/", .$DataFiles$dp_data_files$metadatapath))
isolate(.$DataFiles$dp_data_files$datapath <- gsub("/root/", "~/", .$DataFiles$dp_data_files$datapath))
# savevar$emlal <- .
make_eml(
  path = paste(.$SelectDP$dp_path, .$SelectDP$dp_name, "metadata_templates", sep="/"),
  data.path = paste(.$SelectDP$dp_path, .$SelectDP$dp_name, "data_objects", sep="/"),
  eml.path = paste(.$SelectDP$dp_path, .$SelectDP$dp_name, "eml", sep="/"),
  dataset.title = .$SelectDP$dp_title,
  temporal.coverage = .$Misc$temporal_coverage,
  # geographic.description,
  # geographic.coordinates,
  maintenance.description = "ongoing",
  data.table = .$DataFiles$dp_data_files$name,
  data.description = .$DataFiles$dp_data_files$name
  # data.table.quote.character,
  # other.entity,
  # other.entity.description,
  # data.url,
  # provenance,
  # user.id,
  # user.domain
)

