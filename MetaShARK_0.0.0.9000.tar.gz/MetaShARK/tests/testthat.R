library(testthat)
library(MetaShARK)

test_check("MetaShARK")
