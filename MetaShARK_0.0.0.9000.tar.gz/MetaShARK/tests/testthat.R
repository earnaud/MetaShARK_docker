library(testthat)
library(MetaShARK)

test_dir("tests/testthat/")
