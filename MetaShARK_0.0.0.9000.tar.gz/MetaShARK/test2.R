library(xml2)
library(XML)
library(rvest)

rm(list=ls())

# Read ====
xsd.files <- dir("~/Softwares/Gits/MetaShARK-v2/inst/data-raw/infoBuilder/xsdFiles/", full.names = TRUE)
xsd <- lapply(xsd.files, xmlParse) # read_xml
names(xsd) <- basename(xsd.files)

# Remove unused nodes ====
xpath = "/descendant::xs:annotation"
doc.nodes <- getNodeSet(xsd$`eml-access.xsd`, xpath)
single.xpaths <- paste0("//self::xs:", c("schema", "sequence", "choice"))
sapply(single.xpaths, function(xp){
  getNodeSet(xsd$`eml-access.xsd`, xp) %>%
    replaceNodeWithChildren
})

# replaceNodeWithChildren
