rm(list=ls())

library(XML)

source("~/Softwares/Gits/MetaShARK-v2/inst/data-raw/infoBuilder/exploreXSD.R")

# Read files ====
xsd.files <- dir("~/Softwares/Gits/MetaShARK-v2/inst/data-raw/infoBuilder/xsdFiles/", full.names = TRUE)
xsd <- lapply(xsd.files, xmlParse)
names(xsd) <- basename(xsd.files)

# Prune tree ====
exploreXSD(xsd$`eml-access.xsd`)
exploreXSD(xsd$`eml-attribute.xsd`)

message("Done")