annotateUI <- function(id, title, dev) {
  ns <- NS(id)

  actionButton(
    ns("button"),
    "Annotate", 
    icon("project-diagram")
  )
}

 
#' @importFrom shiny modalDialog tagList tags fluidRow column textInput selectInput modalButton actionButton observeEvent isolate showModal removeModal 
#' @importFrom shinyjs disabled disable enable hide show 
#' @importFrom dplyr %>%
#' @importFrom cedarr search
annotate <- function(input, output, session, savevar, globals, rv, ind) {
  ns <- session$ns
  
  annotateModal <- modalDialog(
    tagList(
      tags$h3(paste("Annotating:", rv$current_table$attributeName[ind])),
      tags$p("Use the below interface to associate an ontological type to 
              your attribute."),
      # search
      fluidRow(
        tags$div(
          id = ns("text"),
          tags$b("Before being able to search for semantic terms, you must head
            to the settings, and type in your CEDAR API Key."),
        )
      ),
      fluidRow(
        column(6,
          textInput(
            ns("search"), "Search term"
          ) %>% disabled
        ),
        column(6,
          selectInput(
            ns("ontology"), "Select ontology in which to search",
            choices = c(`All ontologies` = NA_character_, globals$SEMANTICS$ONTOLOGIES)
          ) %>% disabled
        )
      )
      # result
    ),
    title = "Semantic annotation",
    footer = tags$span(
      modalButton("Cancel"),
      actionButton(ns("done"), "Done") %>% disabled
    )
  )
  
  observeEvent(input$button, {
    showModal(annotateModal)
  }, ignoreInit = TRUE)
  
  observeEvent(globals$SETTINGS$TOKEN$CEDAR, {
    token <- globals$SETTINGS$TOKEN$CEDAR
    if(checkTruth(token)){
      enable("search")
      enable("ontology")
      hide("text")
    }
    else {
      disable("search")
      disable("ontology")
      disable("done")
      show("text")
    }
  }, ignoreInit = FALSE)
  
  observeEvent(input$search, {
    if(isTruthy(input$search) && input$search != "")
      enable("done")
    else
      disable("done")
  })
  
  observeEvent(input$done, {
    removeModal()
    query <- isolate(input$search)
    sources <- isolate(input$ontologies)
    browser()
    .res <- cedarr::search(
      globals$SETTINGS$TOKEN$CEDAR,
      query,
      sources,
      output.mode = "full"
    )
    browser() # if 200, resolve, else, failure.
  })
  
  # Output ----
  return(savevar)
}