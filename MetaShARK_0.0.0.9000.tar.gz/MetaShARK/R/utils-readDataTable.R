#' @title readDataTable
#' 
#' @description Guess the type of the data file (e.g. .xls* or not) and loads it accordingly
#' 
#' @return a data.frame
#' 
#' @param file path to the data table file. For Excel files, 
#' supports "http://", "https://", and "ftp://" URLS.
#' @param ... additional arguments to read.table.
#' 
#' @importFrom gdata read.xls
readDataTable <- function(file, ...){
  if(missing(file))
    stop("Provide a file for this function.")
  
  if(grepl("xlsx?$", file))
    df <- read.xls(file, ...)
  else
    df <- fread(file, ...)
  
  return(df)
}