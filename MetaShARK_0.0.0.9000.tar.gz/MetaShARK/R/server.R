#' @import shiny
#' @importFrom dataone listFormats CNode
#' @importFrom taxonomyCleanr view_taxa_authorities
#' @importFrom shinyjs hide show
#'
#' @noRd
appServer <- function(input, output, session) {
  # get variables
  main.env <- get("main.env", .GlobalEnv)

  assign(
    "current.tab",
    reactive(input$side_menu),
    envir = main.env
  )

  if (main.env$dev)
    observeEvent(input$dev, {
      if (main.env$current.tab() != "fill")
        browser()
    })

  # Update values ====
  invisible({
    # DataONE nodes
    .DATAONE.LIST <- if(!main.env$dev) 
      try(dataone::listFormats(dataone::CNode())) else
        try(silent = TRUE)
    if (class(.DATAONE.LIST) != "try-error") {
      isolate(main.env$dataone.list <- .DATAONE.LIST)
      readDataTable(
        # .DATAONE.LIST,
        isolate(main.env$PATHS$resources$dataoneCNodesList.txt)
      )
    }
  
    # Taxa authorities
    .TAXA.AUTHORITIES <- if(!main.env$dev) 
      try(taxonomyCleanr::view_taxa_authorities()) else
        try(silent = TRUE)
    if (class(.TAXA.AUTHORITIES) != "try-error") {
      isolate(main.env$taxa.authorities <- .TAXA.AUTHORITIES)
      readDataTable(
        # .TAXA.AUTHORITIES,
        isolate(main.env$PATHS$resources$taxaAuthorities.txt)
      )
    }
  })

  ## modules called ----
  fill("fill", main.env)
  upload("upload", main.env)
  documentation("documentation")
  about("about")
  settings("settings", main.env)

  # Hide the loading message when the rest of the server function has executed
  shinyjs::hide(id = "loading-content", anim = TRUE, animType = "fade")
  shinyjs::show("app-content")
}

#' @importFrom dplyr %>% 
#'
#' @noRd
listDP <- function(main.env) {
  list.files(
    main.env$PATHS$eal.dp,
    pattern = "_emldp$",
    full.names = FALSE
  ) %>% gsub(pattern = "_emldp$", replacement = "")
}