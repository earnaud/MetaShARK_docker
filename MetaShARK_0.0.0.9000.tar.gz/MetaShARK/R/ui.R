#' @title .app_ui
#'
#' @description UI part of the mainapp's  script
#'
#' @importFrom golem get_golem_options
#' @importFrom shiny tagList tags actionLink icon span imageOutput actionButton HTML includeCSS
#' @importFrom shinydashboard dashboardPage dashboardHeader dashboardSidebar sidebarMenu menuItem dashboardBody tabItems tabItem
#' @importFrom shinyjs useShinyjs hidden
#' @importFrom shinycssloaders withSpinner
.app_ui <- function() {
  # get app arguments
  appArgs <- get_golem_options()
  dev <- appArgs$dev

  # prepare variable
  menuWidth <- "250px"
  if (!is.logical(dev)) {
    dev <- FALSE
  }
  globals <- .globalScript(dev, reactive = FALSE)

  # action
  tagList(
    includeCSS(system.file("app/www/styles.css", package = "MetaShARK")),
    # List the first level UI elements here
    dashboardPage(
      title = "MetaShARK",
      dashboardHeader(
        tags$li(class = "dropdown", actionLink("appOptions", "", icon("gear"))),
        title = tags$img(src = "media/ms_logo_small.png", width = "200px", height = "50px"),
        titleWidth = menuWidth
      ),
      ## Menus -----------------------------------------------------
      dashboardSidebar(
        useShinyjs(),
        sidebarMenu(
          id = "side_menu",
          menuItem("Welcome",
            tabName = "welcome",
            icon = icon("home")
          ),
          menuItem("Fill in EML",
            tabName = "fill",
            icon = icon("file-import")
          ),
          menuItem("Upload EML",
            tabName = "upload",
            icon = icon("file-export")
          ),
          menuItem("EML Documentation",
            tabName = "documentation",
            icon = icon("glasses")
          ),
          menuItem("About MetaShARK",
            tabName = "about",
            icon = icon("beer")
          ),
          hidden( # Ghost tab for options
            menuItem("appOptions",
              tabName = "appOptions",
              icon = icon("gear")
            )
          ),
          if (isolate(globals$dev)) {
            actionButton(
              "dev", "DEV CHECK"
            )
          }
        ),
        width = menuWidth
      ), # end sidebar
      ## Content -----------------------------------------------------
      dashboardBody(
        tags$script(HTML("$('body').addClass('fixed');")),
        tabItems(
          tabItem(
            tabName = "welcome",
            welcomeUI("welcome")
          ),
          tabItem(
            tabName = "fill",
            fillUI("fill", dev)
          ),
          tabItem(
            tabName = "upload",
            uploadUI("upload", dev, globals)
          ),
          tabItem(
            tabName = "documentation",
            docUI("documentation")
          ),
          tabItem(
            tabName = "about",
            aboutUI("about")
          ),
          tabItem(
            tabName = "appOptions",
            appOptionsUI("appOptions", dev)
          )
        )
      ) # end body
    ) # end dashboard
  ) %>% withSpinner() # end taglist
}
