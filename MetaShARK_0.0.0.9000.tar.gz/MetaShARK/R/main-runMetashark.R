#' @title Run MetaShARK
#'
#' @description Main function for launching the MetaShARK application.
#' 
#' @usage 
#' runMetaShark(...)
#' 
#' @param ... options to pass to the application, ignored if missing or mistyped.
#' \describe{
#'   \item{dev}{logical. Add development elements in the GUI.}
#' }
#'
#' @details MetaShARK (METAdata SHiny Automated Resource & Knowledge) is a web app
#' which is designed to help its user as much as possible for filling ecological
#' metadata. It uses the EML standard (cf. NCEAS work) to allow a full and
#' precise description of input datasets.
#' 
#' @examples
#' # run this to launch MetaShARK
#' runMetashark()
#' 
#' @author Elie Arnaud <elie.arnaud@mnhn.fr>
#'
#' @export
#' @importFrom shiny shinyApp runApp 
#' @importFrom golem with_golem_options
runMetashark <- function(...) {
  
  app = with_golem_options(
    shinyApp(
      ui = .app_ui, 
      server = .app_server,
      onStart = .headerScript
    ),
    golem_opts = list(...)
  )
  
  runApp(
    appDir = app
  )
  
}
