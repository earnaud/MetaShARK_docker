# rm(list=ls())
library(XML)

xsdFiles <- dir("inst/data-raw/infoBuilder/xsdFiles/", full.names = TRUE) %>% gsub("/+","/",.)
# Test on eml.xsd
parsedFile <- xmlTreeParse(xsdFiles[11])
schemaNode <- parsedFile$doc$children$schema
contentList <- xmlToList(schemaNode)