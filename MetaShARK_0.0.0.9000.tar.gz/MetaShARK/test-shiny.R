library(shiny)
library(shinyTree)

#### main ####

ui <- fluidPage(
  sidebarPanel(
    shinyTree("tree", dragAndDrop = TRUE)
  ),
  mainPanel(
    uiOutput("annotation")
  ),
  style = "margin: 15px"
)

server <- function(input, output, session) {
  rv = reactiveValues(
    tree = list(
      a = list(
        a = 1,
        b = 2
      ),
      b = list(
        c = 3,
        d = 4
      )
    )
  )
  
  output$tree <- renderTree(rv$tree)
  
  output$annotation <- renderUI({
    node <- get_selected(input$tree)
    validate(
      need(isTruthy(unlist(node)), "No node selected.")
    )
    return(
      tagList(
        fluidRow(
          column(4, 
            actionButton("subject-button", "Subject")
          ),
          column(4, 
            actionButton("predicate-button", "Predicate")
          ),
          column(4, 
            actionButton("object-button", "Object")
          ),
          style = "border: 2px blue;"
        ),
        uiOutput("detail")
      )
    )
  })
  
  observeEvent(input$subject, {
    output$detail <- renderUI({
      fluidRow(
        textInput("subject-text", "Subject value", "Subject"),
        textInput("context", "Context", "Context"),
        selectInput("element", "EML element", 
          choices = c("Attribute", "dataset", "ResponsibleParty")) # to fetch from documentation later
      )
    })
  })
}

#### module ####



shinyApp(ui, server)

