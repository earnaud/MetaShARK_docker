library("crul")
library("dplyr")

credentials <- list(
  userId = '0000-0003-3416-7653',
  password = readline("Password? ")
)
orcid_sess <- HttpClient$new(
  url = "https://orcid.org",
  headers = list(
    Accept = "application/json"
  )
)
cookie <- curl::handle_cookies(res$handle) %>%
  filter(name == "XSRF-TOKEN") %>%
  select(value) %>%
  unlist %>%
  unname
orcid_sess$headers$`x-xsrf-token` <- cookie

# continue -----------

auth <- orcid_sess$post("/signin/auth.json", body = credentials)
auth$parse()

'https://cn.dataone.org/portal/oauth?action=start'
token <- session$get('https://cn.dataone.org/portal/token')
token$status_http()


# httr ----------

bearer <- rorcid::orcid_auth()
res_2 <-httr::GET(
  'https://cn.dataone.org/portal/oauth?action=start',
  httr::add_headers(Authorization = bearer)
)
# cookies <- res_2$cookies[grepl("JSESSIONID|hazelcast", res_2$cookies$name),]
# n <- cookies$name
# cookies <- unname(cookies$value)
# names(cookies) <- n
res_3 <-httr::GET(
  'https://cn.dataone.org/portal/token',
  httr::add_headers(Authorization = bearer)
)

###

library(shiny)

ui <- fluidPage(
  span(
      actionLink("a","",icon("circle"), style="color: Crimson"),
      actionLink("a","",icon("circle"), style="color: DarkOrange"),
      actionLink("a","",icon("circle"), style="color: Gold")
  )
)

shinyApp(ui, server)