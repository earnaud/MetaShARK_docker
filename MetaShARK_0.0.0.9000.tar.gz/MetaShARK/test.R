# HTTR ----------------------------------------------------------------

library("httr")

sign <- GET('https://orcid.org/signin')
cookie <- as.character(sign$cookies %>% filter(name == "XSRF-TOKEN") %>% select(value))
credentials <- list(
  userId = '0000-0003-3416-7653',
  password = readline("Password? ")
)
auth <- POST(
  'https://orcid.org/signin/auth.json',
  config = list(
    add_headers('x-xsrf-token' = cookie),
    authenticate(
      credentials$userId,
      credentials$password
    )
  )
  # , encode = "json"
)
warn_for_status(auth)

# CRUL ----------------------------------------------------------------

library("crul")

session <- HttpClient$new(
  url = "https://orcid.org"
)
res <- session$get(path = "/signin")
# res$status_http()
cookie <- res$response_headers_all %>% 
  unlist %>% 
  .[grep("XSRF-TOKEN", .)] %>% 
  strsplit(split = "; ") %>% 
  .[[1]] %>% 
  .[1] %>%
  strsplit(split = "=") %>%
  .[[1]] %>%
  .[2]
session$headers$`x-xsrf-token` <- cookie
credentials <- list(
  userId = '0000-0003-3416-7653',
  password = readline("Password? ")
)
auth <- session$post(
  "/signin/auth.json", 
  body = credentials
)
token <- session$get('https://cn.dataone.org/portal/token')
token$status_http()

